-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2023 at 08:26 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tluportal`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(10) UNSIGNED NOT NULL,
  `cat_name` varchar(255) NOT NULL,
  `cat_parent` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_name`, `cat_parent`) VALUES
(1, 'Thời sự', NULL),
(2, 'Thể thao', NULL),
(3, 'Bóng đá', 2),
(4, 'Bóng chuyền', 2);

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `post_id` int(10) UNSIGNED NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_summary` text NOT NULL,
  `post_content` text NOT NULL,
  `author` varchar(50) NOT NULL,
  `dateOfPost` timestamp NOT NULL DEFAULT current_timestamp(),
  `featured_img` varchar(255) NOT NULL,
  `cat_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`post_id`, `post_title`, `post_summary`, `post_content`, `author`, `dateOfPost`, `featured_img`, `cat_id`) VALUES
(1, 'Người đẹp điền kinh Hà Lan phá kỷ lục thế giới', 'Mỹ nhân điền kinh người Hà Lan Femke Bol đã lập kỷ lục thế giới mới tại cự ly chạy 400m trong nhà.', 'Ngôi sao 22 tuổi Femke Bol đã lập kỷ lục thế giới mới tại cự ly chạy 400m trong nhà của nữ tại giải vô địch điền kinh quốc gia Hà Lan đang diễn ra tại Apeldoorn, khi về đích với thành tích 49,26 giây.\r\n\r\nNgười đẹp điền kinh Hà Lan phá kỷ lục thế giới - 1\r\nFemke Bol lập kỷ lục thế giới mới ở đường chạy 400m nữ với thành tích 49,26 giây (Ảnh: GI).\r\n\r\nNgôi sao người Hà Lan đã phá kỷ lục đã tồn tại suốt 41 năm trước đó của nữ vận động viên người CH Séc Jarmila Kratochvilova lập vào tháng 3/1982, với thành tích 49,59 giây.\r\n\r\nTuần trước, tại giải điền kinh trong nhà ở Metz (Pháp), ở cự ly 400m, cô gái 22 tuổi này đã chạy hết 49,96 giây. Và tại Apeldoorn ngày 19/2 vừa qua, Bol cải thiện tiếp 0,7 giây từ thành tích trên để phá khá sâu kỷ lục thế giới cũ tồn tại 41 năm qua.\r\n\r\nNgười đẹp điền kinh Hà Lan phá kỷ lục thế giới - 2\r\nFemke Bol gặt hái được nhiều thành công những năm qua (Ảnh: AP).\r\n\r\n49,26 giây cũng nhanh hơn kỷ lục cá nhân chạy 400m ngoài trời 49,44 giây của Bol khi cô giành chức vô địch châu Âu tại giải đấu ở Munich (Đức) năm 2022. Đó cũng là năm mà Bol giành cả HCV 400m rào nữ lẫn 4x400m tiếp sức nữ cùng đội tuyển điền kinh Hà Lan.\r\n\r\nTại Olympic Tokyo 2020, dù chỉ giành HCĐ ở cự ly 400m vượt rào, nhưng Femke Bol đã lập kỷ lục châu Âu với thành tích 52,03 giây.', 'Kim Anh', '2023-02-20 07:03:39', 'https://icdn.dantri.com.vn/thumb_w/680/2023/02/20/bol2-1676876183424.jpg', 2),
(2, 'Cận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai', 'Tiền đạo Phan Văn Đức (CAHN) có pha vào bóng nguy hiểm với Lê Văn Sơn bên phía CLB Hoàng Anh Gia Lai, dẫn đến tình huống xô dẩy giữa cầu thủ đôi bên.', 'Tình huống xảy ra ở phút 76 của trận CLB Công An Hà Nội (CAHN) gặp Hoàng Anh Gia Lai trong khuôn khổ vòng 4 Night Wolf V-League 2023, diễn ra ở sân Pleiku chiều qua (19/2).\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 1\r\nPhan Văn Đức nhận thẻ vàng vì pha vào bóng nguy hiểm với Lê Văn Sơn (Ảnh: Khoa Nguyễn).\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 2\r\nSau pha vào bóng này, cầu thủ đôi bên lao vào nhau, xô đẩy (Ảnh: Khoa Nguyễn).\r\n\r\nTrong pha bóng này, Phan Văn Đức vào bóng nguy hiểm với Lê Văn Sơn bên phía Hoàng Anh Gia Lai. Tình huống khiến Văn Sơn không giữ được bình tĩnh, anh đứng phắt dậy, lao về phía Phan Văn Đức, muốn \"hỏi cho ra lẽ\".\r\n\r\nCầu thủ đôi bên cũng ngay lập tức lao vào nhau, một số muốn \"phụ họa\" với đồng đội, số khác bình tĩnh hơn thì can ngăn những cái đầu nóng, giúp cho sự việc không xấu thêm.\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 3\r\nTrung vệ ngoại Diakite của Hoàng Anh Gia Lai áp sát Phan Văn Đức (Ảnh: Khoa Nguyễn).\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 4\r\nNgoại binh này cũng muốn giúp đồng đội Lê Văn Sơn, \"hỏi cho ra lẽ\" pha vào bóng của Phan Văn Đức (Ảnh: Khoa Nguyễn).\r\n\r\nSau tình huống này, Phan Văn Đức phải nhận thẻ vàng từ trọng tài Nguyễn Ngọc Châu. \r\n\r\nSau một hồi cãi vã, va chạm, Phan Văn Đức sau đó cũng đã kéo Lê Văn Sơn tách khỏi đám đông. Hai cầu thủ nói gì đó với nhau và tình hình có vẻ dịu đi.\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 5\r\nPhan Văn Đức chủ động kéo tay Lê Văn Sơn (Ảnh: Khoa Nguyễn).\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 6\r\n2 cầu thủ này tách khỏi đám đông, nói gì đó với nhau (Ảnh: Khoa Nguyễn).\r\n\r\nPhan Văn Đức bị HLV Paulo Foiani (người Brazil) bên phía đội CAHN thay ra khỏi sân ở phút 80, tức không lâu sau tình huống lộn xộn xuất phát từ pha vào bóng của chính anh nhằm vào Lê Văn Sơn.\r\n\r\nỞ trận đấu vừa rồi, tuyển thủ quốc gia đang khoác áo đội CAHN không để lại ấn tượng gì đáng kể. Trận đấu kết thúc với kết quả hòa 1-1, làm hài lòng đôi bên.\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 7', 'Trọng Vũ', '2023-02-20 07:04:54', 'https://icdn.dantri.com.vn/thumb_w/680/2023/02/20/pvd1k20-2-23-edited-1676874072740.jpeg', 2),
(3, '62THVA đang học', 'Tiền đạo Phan Văn Đức (CAHN) có pha vào bóng nguy hiểm với Lê Văn Sơn bên phía CLB Hoàng Anh Gia Lai, dẫn đến tình huống xô dẩy giữa cầu thủ đôi bên.', 'Tình huống xảy ra ở phút 76 của trận CLB Công An Hà Nội (CAHN) gặp Hoàng Anh Gia Lai trong khuôn khổ vòng 4 Night Wolf V-League 2023, diễn ra ở sân Pleiku chiều qua (19/2).\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 1\r\nPhan Văn Đức nhận thẻ vàng vì pha vào bóng nguy hiểm với Lê Văn Sơn (Ảnh: Khoa Nguyễn).\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 2\r\nSau pha vào bóng này, cầu thủ đôi bên lao vào nhau, xô đẩy (Ảnh: Khoa Nguyễn).\r\n\r\nTrong pha bóng này, Phan Văn Đức vào bóng nguy hiểm với Lê Văn Sơn bên phía Hoàng Anh Gia Lai. Tình huống khiến Văn Sơn không giữ được bình tĩnh, anh đứng phắt dậy, lao về phía Phan Văn Đức, muốn \"hỏi cho ra lẽ\".\r\n\r\nCầu thủ đôi bên cũng ngay lập tức lao vào nhau, một số muốn \"phụ họa\" với đồng đội, số khác bình tĩnh hơn thì can ngăn những cái đầu nóng, giúp cho sự việc không xấu thêm.\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 3\r\nTrung vệ ngoại Diakite của Hoàng Anh Gia Lai áp sát Phan Văn Đức (Ảnh: Khoa Nguyễn).\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 4\r\nNgoại binh này cũng muốn giúp đồng đội Lê Văn Sơn, \"hỏi cho ra lẽ\" pha vào bóng của Phan Văn Đức (Ảnh: Khoa Nguyễn).\r\n\r\nSau tình huống này, Phan Văn Đức phải nhận thẻ vàng từ trọng tài Nguyễn Ngọc Châu. \r\n\r\nSau một hồi cãi vã, va chạm, Phan Văn Đức sau đó cũng đã kéo Lê Văn Sơn tách khỏi đám đông. Hai cầu thủ nói gì đó với nhau và tình hình có vẻ dịu đi.\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 5\r\nPhan Văn Đức chủ động kéo tay Lê Văn Sơn (Ảnh: Khoa Nguyễn).\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 6\r\n2 cầu thủ này tách khỏi đám đông, nói gì đó với nhau (Ảnh: Khoa Nguyễn).\r\n\r\nPhan Văn Đức bị HLV Paulo Foiani (người Brazil) bên phía đội CAHN thay ra khỏi sân ở phút 80, tức không lâu sau tình huống lộn xộn xuất phát từ pha vào bóng của chính anh nhằm vào Lê Văn Sơn.\r\n\r\nỞ trận đấu vừa rồi, tuyển thủ quốc gia đang khoác áo đội CAHN không để lại ấn tượng gì đáng kể. Trận đấu kết thúc với kết quả hòa 1-1, làm hài lòng đôi bên.\r\n\r\nCận cảnh pha xô đẩy của Phan Văn Đức với cầu thủ Hoàng Anh Gia Lai - 7', 'Trọng Vũ', '2023-02-20 07:04:54', 'https://icdn.dantri.com.vn/thumb_w/680/2023/02/20/pvd1k20-2-23-edited-1676874072740.jpeg', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`),
  ADD KEY `cat_parent` (`cat_parent`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `cat_id` (`cat_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `post_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`cat_parent`) REFERENCES `categories` (`cat_id`);

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`cat_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
